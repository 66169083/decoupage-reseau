from customtkinter import *
from tkinter import ttk
from tkinter import *


def vlsm():
    root = CTk()
    root.geometry("620x560+50+0")
    colums = ["Réseau N°", "adresse Réseau",
    "masque sous réseau","masque"]

    def get_network_number():
        entries = []
        frame = CTkScrollableFrame(root, width=450, height=270)
        frame.place(relx=0.15, rely=0.23)
        number_networks = network_number_entry.get()
        label = CTkLabel(frame, text="Entrer le nombre d'hôtes des réseaux",
                         font=("Helvetica", 23, "bold")).pack()
        for i in range(int(number_networks)):
            i = CTkEntry(frame, corner_radius=30,
                         placeholder_text=" Nombres d'hôtes du Réseau N°" + str(i + 1),
                         font=("Helvetica", 21), width=370, height=52)
            entries.append(i)
            i.pack(pady=18)
        label1.configure(text=entries)

    def get_values():
        list_nombre_hotes = []
        for i in label1.cget("text"):
            list_nombre_hotes.append(i.get())
        return list_nombre_hotes

    def main_function():
        fen=Toplevel(root)
        list_frame=[]
        fen.geometry("1330x680+10+5")
        frame = CTkScrollableFrame(fen, width=1025, height=500)
        frame.place(x=10,y=10)
        j=0
        for i in range(5):
            label_network_ = CTkLabel(frame, text="Réseau N°" + str(j + 1)).pack()
            i=CTkFrame(frame,width=1000,fg_color="blue",height=800)
            i.pack(pady=30)
            table=ttk.Treeview(i,columns=colums,show="headings",height=30)
            table.pack(expand=True)
            for j,i in enumerate(colums):
                table.heading(column=i,text=i)
            #show_table(i,["bonjour","tout","le","monde"],"","","")

            j += 1


            list_frame.append(i)

        return list_frame

    def get_frame_object():
        pass



        pass


    network_number_entry = CTkEntry(root, corner_radius=30, height=45, width=320, font=("Helvetica", 22),
                                    placeholder_text="Entrer le nombre de réseau")
    network_number_entry.place(x=260, y=15)
    label = CTkLabel(root, text="Entrer le nombre de réseau:", font=("Helvetica", 19)).place(x=10, y=20)
    entry_button = CTkButton(root, text="Entrer", height=35, width=150, corner_radius=30, command=get_network_number)
    entry_button.place(x=350, y=70)
    ####################
    label1 = CTkLabel(root, text="")
    entry_ip_address1 = CTkEntry(root, width=220, height=40, font=("Helvetica", 23), corner_radius=40,
                                 placeholder_text="adresse ip")
    entry_ip_address1.place(x=40, y=450)

    masque_initial = CTkEntry(root, width=215, height=40, font=("Helvetica", 23), corner_radius=40,
                              placeholder_text="masque initial")
    masque_initial.place(x=400, y=450)

    valider_button = CTkButton(root, command=main_function, text="voir les résultats", width=150,
                               height=50, corner_radius=30, )
    valider_button.place(x=250, y=500)

    root.mainloop()
#vlsm()
