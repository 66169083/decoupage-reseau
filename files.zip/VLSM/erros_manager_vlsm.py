def gerer_ip_masque_initial(ip_address,masque_initial):
    i
