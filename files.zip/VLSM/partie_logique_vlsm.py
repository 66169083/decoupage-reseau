from reseau.partie_logique import get_list_sous_reseau,get_final_masque


def get_sous_reseau(ip:str,masque_initial,list_nombre_hotes:list):
    list_sous_reseau=[]
    for i in range(len(list_nombre_hotes)):
        masque_final = get_final_masque(list_nombre_hotes[i])
        sous_reseau_courant=get_list_sous_reseau(ip,
        masque_initial,masque_final)
        list_sous_reseau.append(sous_reseau_courant)
        ip=sous_reseau_courant[-1][1][:-3]
        masque_initial=get_final_masque(list_nombre_hotes[i])



    return list_sous_reseau


list_nombre_hote=["75","50","25"]
list_sous=get_sous_reseau("192.168.3.0",24,list_nombre_hote)
for i in list_sous:
    print(i)