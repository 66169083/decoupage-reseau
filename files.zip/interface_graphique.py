from tkinter import *
from customtkinter import *
from tkinter import messagebox
from show_table import show_tables
import partie_logique as cal
import errors_manager as manage
from change_theme_color import change_theme_color

#from partie_logique import calcul_masque as cal
root = CTk()
set_default_color_theme("green")
root.geometry("600x530+5+5")
root.maxsize(600,530)
root.title("affiche sous réseau")
colums = ["Réseau N°", "adresse Réseau", "masque sous réseau"]
change_theme_color(root,x=0,y=500)



def fonction1():
    masque_final = entry_masque_final.get()
    masque_intial = entry_masque_intial.get()
    ip_address1 = entry_ip_address1.get()

    return ip_address1, masque_intial, masque_final


def fonction2():
    ip_address2 = entry_ip_address2.get()
    nombre_bits = entry_nombre_bits.get()
    return ip_address2, nombre_bits


def afficher_sous_reseau1():
    value = cal.calucul_sr_masq_init_masq_final(fonction1()[0], fonction1()[1], fonction1()[2])
    manager_error = manage.gerer_adresse_ip(fonction1()[0])
    print(manager_error)
    if manager_error[0]:
        show_tables(colums, values=value)
    else:
        messagebox.showerror("erreur ip ", str(manager_error[1]))
    pass


def afficher_sous_reseau2():
    pass


def show_default_masque():
    """try:
        ip = entry_ip_address1.get()
        if manage.gerer_adresse_ip(ip)[0]:
            defaut_masque.set(cal.get_genique_masque(ip))
            #entry_masque_intial.configure(textvariable=defaut_masque)
            #entry_masque_final.configure(textvariable=defaut_masque)
        elif  not manage.gerer_adresse_ip(ip)[0]:
            #defaut_masque.set("")
            entry_masque_intial.configure(textvariable=DISABLED)
            entry_masque_final.configure(textvariable=DISABLED)
    except:

        pass
    root.after(100,show_default_masque)
defaut_masque=StringVar(root,"")"""

ip_label = CTkLabel(root, text="IP:", font=("Helvetica", 16)).place(x=15, y=40)
entry_ip_address1 = CTkEntry(root, width=160, font=("Helvetica", 15), corner_radius=40, placeholder_text="adresse ip")
entry_ip_address1.place(x=40, y=40)

entry_masque_intial = CTkEntry(root, width=160, font=("Helvetica", 15), corner_radius=40,
                               placeholder_text="Masque initial")
entry_masque_intial.place(x=230, y=40)
entry_masque_final = CTkEntry(root, width=160, font=("Helvetica", 15), corner_radius=40,
                              placeholder_text="Masque final")
entry_masque_final.place(x=420, y=40)

ip_label2 = CTkLabel(root, text="IP:", font=("Helvetica", 16)).place(x=15, y=220)

entry_ip_address2 = CTkEntry(root, width=160, font=("Helvetica", 15), corner_radius=40, placeholder_text="adresse ip")
entry_ip_address2.place(x=40, y=220)

#label_nombre_bit_masque=CTkLabel(root,text="/ du masque:",font=("Helvetica", 19 )).place(x=280,y=220)
entry_nombre_bits = CTkEntry(root, width=190, font=("Helvetica", 15), corner_radius=40,
                             placeholder_text="nombre bits ou masque")

entry_nombre_bits.place(x=220, y=220)
#or_label=CTkLabel(root,text="OU",font=("Helvetica", 19 )).place(x=300,y=200)

show_sub_net_button = CTkButton(root, text="Afficher les résultats", corner_radius=40, height=40,
                                command=afficher_sous_reseau1, font=("Helvetica", 15))
show_sub_net_button.place(x=220, y=100)

show_all_info_button = CTkButton(root, text="Afficher les résultats", corner_radius=40, height=40,
                                 command=afficher_sous_reseau2, font=("Helvetica", 15))
show_all_info_button.place(x=240, y=280)

show_all_info_button = CTkButton(root, text="Options Avancées avec VLSM", corner_radius=40, height=35,
                                 command=afficher_sous_reseau1, font=("Helvetica", 17))
show_all_info_button.place(x=300, y=490)

entry_masque_final2 = CTkEntry(root, width=140, font=("Helvetica", 15), corner_radius=40,
                               placeholder_text="Nombre d'hôtes")
entry_masque_final2.place(x=430, y=220)

resultat_label = Label(root, text="", font="Helvetica 18 bold")

#resultat_label.place(x=60, y=200)

root.after(100,show_default_masque)
root.mainloop()
