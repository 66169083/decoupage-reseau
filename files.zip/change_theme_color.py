from customtkinter import *
def change_theme_color(root,x,y):
    def combo_fonction(*args):
        theme = theme_color_combox.get()
        set_appearance_mode(theme)
    list_themes = ["dark", "light"]
    theme_color_combox = CTkComboBox(root, values=list_themes, dropdown_hover_color="green",dropdown_font=("Helvetica", 18), border_width=1, state="readonly",font=("Helvetica", 18), command=combo_fonction)
    theme_color_combox.place(x=x, y=y)
    theme_color_combox.set("Select theme")