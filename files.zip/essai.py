def get_list_sous_reseau_classe_C(ip_address: str, pas, nombre_sous_reseau: int):
    list_sous_reseau, ip, list_oct ,octet4_value= [["1", ip_address]], "", ip_address.split(".", 4),0
    octet3_value, octet2_value, octet1_value=0,0,0
    octet_value=[octet4_value,octet3_value,octet2_value,octet1_value]
    for i in range(nombre_sous_reseau-1):
        if octet4_value + pas < 255:
            octet4_value = pas+octet4_value+int(list_oct[3])
        else:
            octet4_value=0
            if octet3_value+1<=255:
                octet3_value+=1
            else:
                octet3_value=0
                if octet2_value+1<=255:
                    octet2_value+=1
                else:
                    octet2_value=0
                    if octet1_value+1<255:
                        octet1_value+=1
                    else:
                        octet1_value=0
        for j in range(4):
            list_oct[3-j]=str(int(list_oct[3-j])+octet_value[3-j])

        somme=int(list_oct[3])+octet4_value
        list_oct[3],ip=str(somme),""
        for j in list_oct:
            ip += "." + j
        ip = ip[1:]
        list_sous_reseau.append([str(i + 2), ip])
        list_oct[3],ip = "0",""

    return list_sous_reseau

print(get_list_sous_reseau_classe_C("172.160.2.0",32,800))