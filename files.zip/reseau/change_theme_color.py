from customtkinter import *
def change_theme_color(root,x,y):
    def set(*args):
        set_appearance_mode(button.get())
    label=CTkLabel(root,text="Mode Sombre",font=("Bookman Old Style",17)).place(x=x,y=y)
    button=CTkSwitch(root,text="",switch_width=50,switch_height=25,hover=False,corner_radius=20,command=set,onvalue="dark",offvalue="light")
    button.place(x=x+120,y=y+5)
    root.mainloop()