import customtkinter as ct
from database.logique import insert_values as ins
from threading import Thread
from time import sleep
root = ct.CTk()
ct.set_appearance_mode("light")
root.geometry("600x600")
ct.set_default_color_theme("green")


def save():
    sleep(1)
    print("succès")

def thread():
    thread1=Thread(target=save)
    thread1.start()

label = ct.CTkLabel(root, text="Entrer votre identifiant:", )

save_button = ct.CTkButton(root, text="Enregistrer les données",
    corner_radius=50, command=thread, height=50)
save_button.place(x=220, y=300)

table = ct.CTkTabview(root, width=150, height=150, corner_radius=50, segmented_button_unselected_color="white", )
table.place(x=320, y=380)
root.mainloop()
