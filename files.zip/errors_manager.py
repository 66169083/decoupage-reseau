from math import log2


def gerer_adresse_ip(ip_address: str):
    resultat = False
    list_errors=[]
    try:
        nombre_ponit, index_point = 0, []
        for j, i in enumerate(ip_address):
            if i == ".":
                index_point.append(j)
                nombre_ponit += 1
        for i in index_point:
            if not ip_address[i + 1].isdigit():
                list_errors.append("adresse invalide")
                raise ValueError
        if nombre_ponit != 3:
            list_errors.append("adresse invalide")
            raise ValueError
        octet_ip = ip_address.split(".", 4)
        for i in octet_ip:
            if not i.isdigit():
                list_errors.append(f"{i} doit être un entier")
                raise ValueError
            if int(i) > 254:
                list_errors.append(f"{i} doit être <254")
                raise ValueError
            if int(octet_ip[0]) >= 224 or int(octet_ip[0]) < 1:
                list_errors.append(f"{i} doit etre un compris entre 1 ete 223")
                raise ValueError
        resultat = True
    except:
        pass
    return resultat,list_errors
"print(gerer_adresse_ip(""))"


def manage_masque(masque: str):
    resultat = False
    try:
        list_oct_masque, nombre_point, nombre_225 = masque.split(".", 4), 0, []
        for i in masque:
            if i == ".":
                nombre_point += 1
        if nombre_point != 3:
            raise ValueError
        authorise_octetl_list = [0, 128, 192, 224, 240, 248, 252, 254, 255]
        for j, i in enumerate(list_oct_masque):
            i = int(i)
            if not int(i) in authorise_octetl_list:
                raise ValueError
            if int(i) > 255 and int(i) < 1:
                raise ValueError
            if int(i) == 255:
                nombre_225.append(j)
        for i in range(nombre_225[-1]):
            if int(list_oct_masque[i]) != 255:
                raise ValueError

        resultat = True
    except:
        pass
    return resultat


def nombre_bit_masque(nombre_bits: str):
    resultat = False
    try:
        if not nombre_bits.isdigit():
            raise ValueError
        if int(nombre_bits) > 31 or int(nombre_bits) < 1:
            raise ValueError
        nombre_bits = int(nombre_bits)
        resultat = True
    except:
        pass
    return resultat

def gerer_masque_init_final(masque_initial:str,masque_final:str):
    resultat=False
    list_error=[]
    try:
        masque_final_octet=masque_final.split(".",4)
        masque_initial_octet=masque_initial.split(".",4)
        diff_octet=[]
        for i in range(4):
            diff_octet.append(int(masque_final_octet[i])-int(masque_initial_octet[i]))
        for i in diff_octet:
            if i<0:
                raise ValueError

        resultat=True
    except:
        pass
    return  resultat
def gerer_ip_masque():
    pass
#print(gerer_masque_init_final("255.255.224.0","255.255.0.0"))

#print(manage_masque("255.255.255.128"))
#print(nombre_bit_masque("17"))
