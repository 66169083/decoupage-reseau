from conversions_ import conversion_start_base_number_end_base as f
import math as m


def ETlogique(octet1, octet2):
    list_bits_oct1, list_bits_oct2, resultat = [], [], ""
    while len(octet1) != 8:
        octet1 = "0" + octet1
    while len(octet2) != 8:
        octet2 = "0" + octet2
    for i in range(8):
        list_bits_oct2.append(octet2[i])
        list_bits_oct1.append(octet1[i])
    for i in range(8):
        resultat += str(int(list_bits_oct1[i]) * int(list_bits_oct2[i]))
    return resultat
def get_position_insertion_reseau(masque_final):
    nombre_hotes=2**(32-get_nombre_bits_avec_masque(masque_final))
    if nombre_hotes<=254:
        return 0
    elif 254<nombre_hotes <=65534:
        return 1
    elif nombre_hotes>=65534:
        return 2
    elif nombre_hotes >= 16777214:
        return 3
def find_network_class(ip_address: str):
    classe = ""
    list_octet_ip_address = ip_address.split(".", 4)
    if 1 <= int(list_octet_ip_address[0]) < 128:
        classe = "A"
    elif 128 <= int(list_octet_ip_address[0]) < 191:
        classe = "B"
    elif 191 <= int(list_octet_ip_address[0]) < 223:
        classe = "C"
    else:
        pass
    return classe

def get_genique_masque(ip_address):
    masque = ""
    network_class = find_network_class(ip_address)
    if network_class == "A":
        masque = "255.0.0.0"
    elif network_class == "B":
        masque = "255.255.0.0"
    elif network_class == "C":
        masque = "255.255.255.0"
    else:
        pass
    return masque
def get_nombre_bits_avec_masque(masque: str):
    list_octet_masque = masque.split('.', 4)
    list_bits_a_1 = ""
    for i in list_octet_masque:
        list_bits_a_1 += str(f(10, int(i), 2))
    resultat = 0
    resultat = len(list_bits_a_1.split("0")[0])
    return resultat
def get_list_sous_reseau_classe_C(ip_address: str, pas, nombre_sous_reseau: int):
    list_sous_reseau, ip, list_oct ,octet4_value= [["1", ip_address]], "", ip_address.split(".", 4),0
    octet3_value,octet2_value,octet1_value=0,0,0
    for i in range(nombre_sous_reseau-1):
        if octet4_value + pas < 255:
            octet4_value = pas+octet4_value+int(list_oct[3])
        else:
            octet4_value=0
            if octet3_value+1<=255:
                octet3_value+=1
            else:
                octet3_value=0
                if octet2_value+1<=255:
                    octet2_value+=1
                else:
                    octet2_value=0
                    if octet1_value+1<255:
                        octet1_value+=1
                    else:
                        octet1_value=0
        somme=int(list_oct[3])+octet4_value
        list_oct[3],ip=str(somme),""
        for j in list_oct:
            ip += "." + j
        ip = ip[1:]
        list_sous_reseau.append([str(i + 2), ip])
        list_oct[3 ],ip = "0",""
    return list_sous_reseau

#print(get_list_sous_reseau_classe_C("172.160.2.0",32,8))
def calcul_masque_avec_nbr_bits(nombre_de_bits: int):
    nombre_octet, nombre_de_bit, nombre_octet_value, list_zero, nombre_de_bits_restant = nombre_de_bits // 8, nombre_de_bits % 8, "", [
        "0", "0", "0"], ""
    for i in range(nombre_octet):
        nombre_octet_value += "255."
    for i in range(nombre_de_bit):
        nombre_de_bits_restant += "1"
    for i in range(8 - nombre_de_bit):
        nombre_de_bits_restant = str(nombre_de_bits_restant) + "0"
    masque = str(nombre_octet_value) + str(f(2, int(nombre_de_bits_restant), 10))
    for i in range(3 - nombre_octet):
        masque += ".0"
    return masque


def calcul_adresse_reseau(adresse_ip: str, masque: str):
    resultat = ""
    list_octet_decimal_adress_ip = adresse_ip.split(".", 4)
    list_octect_decimal_masque = masque.split(".", 4)
    for i in range(4):
        resultat = resultat + "." + str(f(2, int(ETlogique(f(10, int(list_octect_decimal_masque[i]), 2),
                                                           f(10, int(list_octet_decimal_adress_ip[i]), 2))), 10))
    resultat = resultat[1:]
    return resultat


#print(calcul_adresse_reseau("172.16.77.120","255.255.240.0"))

def calcul_sous_reseau_avec_nbr_hote(ip_adress: str, masque_initial: str, nombre_hotes: int):
    n = m.ceil(m.log(nombre_hotes - 2, 2))
    nombre_sous_reseau = 2 ** n
    adress_sous_reseau1 = ""
    octet_binaire_masque = ""
    octet_du_masque = masque_initial.split(".", 4)
    octet_binaire_address_ip = ip_adress.split(".", 4)
    print(octet_binaire_address_ip)
    nombre_octet_255 = 0
    list_bits_octet = []
    for i in range(4):
        list_bits_octet.append(f(10, int(octet_du_masque[i]), 2))
        if octet_du_masque[i] == "255":
            nombre_octet_255 += 1
    for i in range(4):
        for k in range(8 - len(list_bits_octet[i])):
            list_bits_octet[i] += "0"
        octet_binaire_masque += list_bits_octet[i]
    list_bits_masque, list_bits_a_1, resultat_list, list_bits_adress_ip = [], [], [], []
    resultat_ = ""
    for i in range(32):
        list_bits_masque.append(octet_binaire_masque[i])
        list_bits_adress_ip.append(f(10, int(octet_binaire_address_ip[i]), 2))
    for i in range(8 * nombre_octet_255 + n):
        list_bits_a_1.append('1')
    for i in range(32 - (8 * nombre_octet_255 + n)):
        list_bits_a_1.append("0")
    for i in range(32):
        resultat_list.append((str(int(list_bits_masque[i]) + int(list_bits_a_1[i]))).replace("2", "1"))
        resultat_ += resultat_list[i]
    #calcul du nouveau masque
    masque = ""
    for i in range(4):
        masque += "." + str(f(2, int(resultat_[8 * i:8 * (i + 1)]), 10))
    masque = masque[1:]
    adress_sous_reseau1 = calcul_adresse_reseau(ip_adress, masque)

    network_class = find_network_class(ip_adress)

    if network_class == "A":
        pass
    elif network_class == "B":
        pass
    elif network_class == "C":
        pass
    else:
        pass
    return list_bits_adress_ip
def calcul_sous_reseau_avec_masque(masque_initial: str, masque_final: str, ip_address: str):
    list_octect_masq_init, list_octect_masq_final, list_octect_adress_ip = masque_initial.split(".",
                                                                                                4), masque_final.split(
        ".", 4), ip_address.split(".", 4)
    diff_octet_non_nul = ""
    nombre_bits_1 = ""
    j = 0
    for i in range(4):
        nombre_bits_1 += f(10, int(list_octect_masq_final[i]), 2)
        diff = int(list_octect_masq_final[i]) - int(list_octect_masq_init[i])
        if diff != 0:
            j += 1
            diff_octet_non_nul += f(10, int(diff), 2)
    m = len(nombre_bits_1.split("0")[0])
    n = len(diff_octet_non_nul.split("0")[0])
    nombre_address_reseau = 2 ** n
    first_network_add = calcul_adresse_reseau(ip_address, masque_final)
    first_network_add_octet_list = first_network_add.split(".", 4)
    nombre_hotes = 2 ** (32 - m)
    last_octet_add = first_network_add_octet_list[-1]

    return first_network_add_octet_list, nombre_hotes, n, m, last_octet_add
def test(ip_address: str, masque_initial: str, nombre_hotes: int,masque_final:str):
    list_sous_reseau = []
    n = m.ceil(m.log(nombre_hotes + 2, 2))
    nombre_bits_partie_net = 32 - n
    nombre_hotes = 2 ** n
    nombre_bit_sr = (nombre_bits_partie_net - get_nombre_bits_avec_masque(masque_initial))
    nombre_sous_reseau = 2 ** nombre_bit_sr
    #masque_final = calcul_masque_avec_nbr_bits(32 - n)
    address_sous_reseau1 = calcul_adresse_reseau(ip_address, masque_final)
    network_class = find_network_class(ip_address)

    list_octet_premier_sr = []
    if nombre_hotes < 255:
        list_sous_reseau = get_list_sous_reseau(address_sous_reseau1, nombre_hotes, 2 ** nombre_bit_sr)
    else:
        pass

    reste_div_nombres_sr_256_list = address_sous_reseau1.split(".", 4)
    for i in range(3):
        reste_div_nombres_sr_256_list.append(nombre_sous_reseau // 256)
        nombre_sous_reseau /= 256
    nombre_zero_in_rest = 0
    for i in reste_div_nombres_sr_256_list:
        if i != 0:
            nombre_zero_in_rest += 1
    print(nombre_bits_partie_net, masque_final, 2 ** nombre_bit_sr,masque_final)
    return list_sous_reseau
def calucul_sr_masq_init_masq_final(ip_address,masque_initial,masque_final):
    list_sous_reseau = []
    n=get_nombre_bits_avec_masque(masque_final)-get_nombre_bits_avec_masque(masque_initial)
    nombre_hotes = 2**(32-get_nombre_bits_avec_masque(masque_final))
    print(nombre_hotes)
    nombre_sous_reseau = 2 ** n
    address_sous_reseau1 = calcul_adresse_reseau(ip_address, masque_final)
    position_octet=get_position_insertion_reseau(masque_final)
    nombre_hotes1,nombre_hotes2,nombre_hotes3=nombre_hotes,nombre_hotes//256,(nombre_hotes//256)//256
    if nombre_hotes <=254:
        list_sous_reseau = get_list_sous_reseau(address_sous_reseau1, nombre_hotes1,position_octet, nombre_sous_reseau)
    elif 254<=nombre_hotes<=65534:
        list_sous_reseau = get_list_sous_reseau(address_sous_reseau1, nombre_hotes2, position_octet,nombre_sous_reseau)
    elif nombre_hotes>=65534:
        list_sous_reseau = get_list_sous_reseau(address_sous_reseau1,nombre_hotes3,position_octet, nombre_sous_reseau)

    return position_octet,list_sous_reseau
def calcul_sr_nombre_hotes(ip_address,nombre_hotes,masque_initial):
    list_sous_reseau = []
    n = m.ceil(m.log(nombre_hotes + 2, 2))
    nombre_hotes = 2 ** n
    masque_final=calcul_masque_avec_nbr_bits(32-n)

    nombre_sous_reseau = 2 **(32-n-get_nombre_bits_avec_masque(masque_initial))
    print(nombre_sous_reseau)
    address_sous_reseau1 = calcul_adresse_reseau(ip_address, masque_final)
    if nombre_hotes < 255:
        list_sous_reseau = get_list_sous_reseau(address_sous_reseau1, nombre_hotes, nombre_sous_reseau)
    else:
        pass
    return list_sous_reseau
def check_final_masque(ip_address,initial_masque,final_masque):
    diff_masque=get_nombre_bits_avec_masque(final_masque)-get_nombre_bits_avec_masque(initial_masque)
    class_ip=find_network_class(ip_address)




#print(get_nombre_bits_avec_masque("255.255.224.0"))
#print(test("192.168.25.36","255.255.255.128",100))


#print(find_network_class("1722.10.10.25")!="")

#print(calcul_sous_reseau_avec_masque("255.255.255.0", "255.255.255.224", "172.168.1.1"))
def get_list_sous_reseau_classe_B(ip_address: str, pas, nombre_sous_reseau: int):
    list_sous_reseau, ip, list_oct = [["1", ip_address]], "", ip_address.split(".", 4)
    octet4_value, octet3_value = 0,0
    list_hotes_value=[]
    for i in range(nombre_sous_reseau-1):
        if octet4_value + pas < 255:
            octet4_value = pas+octet4_value+int(list_oct[3])
        else:
            octet4_value=0
            if octet3_value+1<256:
                octet3_value += 1
            else:
                octet3_value=0
        somme=int(list_oct[3])+octet4_value
        somme1=int(list_oct[3-(-1)])+octet3_value
        list_oct[2]=str(somme)
        list_oct[2]=str(somme1)
        print(octet3_value,octet4_value,somme,somme1)
        ip = ""
        for j in list_oct:
            ip += "." + j
        ip = ip[1:]
        list_sous_reseau.append([str(i + 2), ip])
        ip = ""
        list_oct[2 ] = "0"
        list_oct[2] = "0"
    return list_sous_reseau

#print(get_list_sous_reseau("172.160.2.0",32,3,8))
def get_list_sous_reseau_classe_A(ip_address: str, pas,nombre_sous_reseau: int):
    list_sous_reseau, ip, list_oct = [["1", ip_address]], "", ip_address.split(".", 4)
    octet1_value, octet2_value, octet3_value, octet4_value = 0, 0, 0, 0
    for i in range(nombre_sous_reseau-1):
        if octet4_value + pas < 255:
            octet4_value = pas+octet4_value+int(list_oct[3])
        else:
            octet4_value=0
            if octet3_value+1<256:
                octet3_value += 1
            else:
                octet3_value=0
        somme=int(list_oct[3])+octet4_value
        somme1=int(list_oct[3-(-1)])+octet3_value
        list_oct[3-+1]=str(somme)
        list_oct[3]=str(somme1)
        print(octet3_value,octet4_value,somme,somme1)
        ip = ""
        for j in list_oct:
            ip += "." + j
        ip = ip[1:]
        list_sous_reseau.append([str(i + 2), ip])
        ip = ""
        list_oct[3] = "0"
        list_oct[3] = "0"
    return list_sous_reseau

#print(get_list_sous_reseau("172.160.2.0",32,3,8))