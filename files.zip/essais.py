from customtkinter import *
from tkinter import ttk
from tkinter import *
def essai():
    root=CTk()
    style=ttk.Style()
    style.configure("Treeview.Heading",font="Helvetica 16 bold",borderwith=0,background="black",relief="solid")
    style.configure("Treeview",font="Helvetica 25",borderwith=1,relief="solid",pady=10)
    colums=["Réseau N°", "adresse Réseau", "masque sous réseau"]
    table=ttk.Treeview(root,columns=colums,show="headings",height=200)
    scrobar=Scrollbar(orient="vertical",command=table.yview)
    for i in colums:
        table.heading(i,text=i)
    scrobar.pack(fill="y",side="right")
    table.pack(fill=BOTH)

    table.insert(parent="",index=0,values=(1,"192.168.3.6","255.255.255.0"))
    table.insert(parent="",index=0,values=(1,"172.168.3.6","255.255.128.0"))
    table.column("Réseau N°",width=120)
    root.geometry("700x600")
    root.mainloop()
